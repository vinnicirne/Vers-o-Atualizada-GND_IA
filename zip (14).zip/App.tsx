import React from 'react';

function App() {
  return (
    <div style={{ padding: '20px', textAlign: 'center', fontFamily: 'sans-serif' }}>
      <h1>Empty App</h1>
      <p>This is a minimal React application.</p>
    </div>
  );
}

export default App;