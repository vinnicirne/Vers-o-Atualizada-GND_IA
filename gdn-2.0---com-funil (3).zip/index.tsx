// Arquivo index vazio conforme solicitado
export {};
